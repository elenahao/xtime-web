# xtime-web

## Project setup
```
yarn install || yarn i
```

### Compiles and minifies for production
```
yarn build
```

### Run your dev
```
yarn start
```
