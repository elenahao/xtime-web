<template>
    <el-container>
        <el-aside width="200px"
                  class="sidebar">
            <Sidebar />
        </el-aside>
        <el-main>
            <el-breadcrumb separator="/">
                <el-breadcrumb-item>1</el-breadcrumb-item>
                <el-breadcrumb-item>2</el-breadcrumb-item>
                <el-breadcrumb-item>3</el-breadcrumb-item>
                <el-breadcrumb-item>4</el-breadcrumb-item>
            </el-breadcrumb>
            <router-view></router-view>
        </el-main>
    </el-container>
</template>
<script>
import Sidebar from './Sidebar'
export default {
    components: {
        Sidebar
    }
}
</script>