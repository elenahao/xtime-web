<template>
    <div>
        <h1>Hello World</h1>
    </div>
</template>
<script>
export default {
    name: "Home"
}
</script>
