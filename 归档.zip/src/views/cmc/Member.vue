<template>
    <div>
        <h1>会员管理</h1>
    </div>
</template>
<script>
export default {
    name: "member"
}
</script>
