<template>
    <div>
        <h1>卖品管理</h1>
    </div>
</template>
<script>
export default {
    name: "snack"
}
</script>
