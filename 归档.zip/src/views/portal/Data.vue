<template>
    <div>
        <h1>个人信息设置</h1>
    </div>
</template>
<script>
export default {
    name: "data"
}
</script>
