<template>
    <div>
        <h1>密码设置</h1>
    </div>
</template>
<script>
export default {
    name: "password"
}
</script>
