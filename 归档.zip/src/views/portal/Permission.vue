<template>
    <div>
        <h1>权限管理</h1>
    </div>
</template>
<script>
export default {
    name: "permission"
}
</script>
