<template>
    <div>
        <h1>角色管理</h1>
    </div>
</template>
<script>
export default {
    name: "role"
}
</script>
