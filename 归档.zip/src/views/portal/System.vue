<template>
    <div>
        <h1>系统管理</h1>
    </div>
</template>
<script>
export default {
    name: "system"
}
</script>
