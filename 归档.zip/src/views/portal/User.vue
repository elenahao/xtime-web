<template>
    <div>
        <!-- <h1>{{getBreadCrumb}}</h1> -->
    </div>
</template>
<script>
export default {
    name: "user",
    data() {
        return {}
    },
    methods: {

    }
}
</script>
