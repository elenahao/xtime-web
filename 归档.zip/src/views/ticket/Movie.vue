<template>
    <div>
        <h1>影片管理</h1>
    </div>
</template>
<script>
export default {
    name: "movie"
}
</script>
